# hello_ridwaanhall

A package that says hello to Ridwaan.

## Installation

```sh
pip install hello_ridwaanhall
```

## Usage

```python
from hello_ridwaanhall import hello

print(hello.hi())
```
