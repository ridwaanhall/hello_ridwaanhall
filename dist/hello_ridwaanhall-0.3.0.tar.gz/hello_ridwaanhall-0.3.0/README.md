# hello_ridwaanhall

A package that says hello to Ridwaan.

## Installation

```sh
pip install hello_ridwaanhall
```

## Usage

```python
from hello_ridwaanhall import hello, me

print(hello.hi())
print(hello.love())

print(me.username())
print(me.nim())
print(me.name())
print(me.email())
print(me.college())
```
