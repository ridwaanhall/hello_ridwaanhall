def username():
    return "ridwaanhall"

def nim():
    return "5210411257"

def name():
    return "Ridwan Halim"

def email():
    return "ridwaanhall.dev@gmail.com"

def college():
    return f"{nim()}_{name()}"
