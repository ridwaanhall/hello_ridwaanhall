def hi():
    return "Hello, ridwaanhall!"

def love():
    return "I love you, afidaafkaa!"