# hello_ridwaanhall/main.py

def hi():
    return "Hello, ridwaanhall!"
